import React from 'react';
import Navbars from './components/navbar.js';
import Contents from './components/contents.js';
import 'bootstrap/dist/css/bootstrap.min.css';
import { DatePicker } from 'antd';

function App() {
  return(
    <div>
      <Navbars></Navbars>
      <Contents></Contents>
    </div>
  );
}
export default App;
