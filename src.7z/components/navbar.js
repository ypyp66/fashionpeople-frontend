import React, { Component } from 'react';
import "antd/dist/antd.css";
import './css/navbar.css';
import {Button,Navbar,Nav} from 'react-bootstrap';

class Navbars extends Component{
  render(){
    return (
    <div style={{position:'fixed', display:'inline-block', width:'100%'}}>
      <Navbar bg="light" expand="lg">
      <Navbar.Brand href="#home" style={{fontSize:'2rem'}}>OOTD</Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="mr-auto">
        </Nav>
        <Nav inline>
          <Nav.Link href="#home">피드백</Nav.Link>
          <Nav.Link href="#link">마켓</Nav.Link>
          <Nav.Link href="#link">랭킹</Nav.Link>
          <Button variant="outline-success" style={{fontSize:'0.9rem', marginLeft:'4rem'}}>로그인/회원가입</Button>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
    </div>
    
  );
  }
}

export default Navbars;
