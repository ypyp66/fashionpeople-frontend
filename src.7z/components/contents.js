import React from 'react';
import './css/contents.css';
import styled from "styled-components";


const Contents = () => {
    return (
        <div>
            <Container>
                OOTD
            </Container>
            <div style={{margin:"5rem" ,display:"flex", justifyContent:"center"}}>
                <div>
                    <Market ></Market>
                    <div style={{textAlign:"center"}}><a href="#">마켓</a></div>
                </div>
                <div style={{marginRight: "5rem", marginLeft: "5rem"}}>
                    <Feedback></Feedback>
                    <div style={{textAlign:"center"}}>피드백</div>
                </div>
                <div>
                    <Ranking></Ranking>
                    <div style={{textAlign:"center"}}>랭킹</div>
                </div>
            </div>
            
        </div>
    );
  };
  const Container = styled.div`
  display: flex;
  width: 100%;
  height: 40vh;
  font-size: 10rem;
  color: yellow;
  background: url(https://lh3.googleusercontent.com/proxy/Aik1kTePrAg8gPfa97ru8FBn_8xW4hFbGxNspvhoblWglmFX-b5XOemSWTsnY3uVbCfWumfk6yuuHXWGzZ_yM6mtGvF9FPhGi7COMrnOzNuGeTP3c9OzM1hLl-knigZLKAqRTMDcNZw);
  background-size: cover;
  justify-content: center;
  align-items: center;
`;
  const Market = styled.div`
    background: url('http://img.lifestyler.co.kr/uploads/program/1/1765/menu/2/html/f131755988183457049(0).jpg');
    height: 35vh;
    width: 17vw;
  `;
  const Feedback = styled.div`
    background: url(https://lh3.googleusercontent.com/proxy/tf8J0fpF54XUcW17Jihv6hwvTpaMNrhATd7Qlr_GfRT8GjTYwfYAKkdzKpGQAKHbea9mMiGPiV-Ng6qqQSEJS_mmQI18HRupDqIjYSAYxPHbVdSeaY-VU-KeRNqEd0NKLBP3roGzd8UKUQ32w_kzukY);
    height: 35vh;
    width: 17vw;
    
  `;
  const Ranking = styled.div`
    background: url('http://img.lifestyler.co.kr/uploads/program/1/1765/menu/2/html/f131755991405189701(0).jpg');
    height: 35vh;
    width: 17vw;
  `;
  export default Contents;